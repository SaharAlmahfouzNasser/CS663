

from PIL import Image
import matplotlib.pyplot as plt
import cv2
import numpy as np
from pykalman import KalmanFilter

#Function to compute the centre of the region of interest
def ROI_cent(A):
    x = (A[0][0] + A[1][0] + A[2][0] + A[3][0]) / 4.0
    y = (A[0][1] + A[1][1] + A[2][1] + A[3][1]) / 4.0
    return np.array([np.float32(x), np.float32(y)], np.float32)

#Kalman filter
#dynamParams	->Dimensionality of the state=4
#measureParams->	Dimensionality of the measurement=2
kalman = cv2.KalmanFilter(4,2)

kalman.measurementMatrix = np.array([[1,0,0,0],[0,1,0,0]],np.float32)  
#Transition matrix->To predict next state
kalman.transitionMatrix = np.array([[1,0,1,0],[0,1,0,1],[0,0,1,0],[0,0,0,1]],np.float32) 

kalman.processNoiseCov = np.array([[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]],np.float32) * 0.03

#Capturing the real time video from laptop camera
cap=cv2.VideoCapture(0)
_,first_frame=cap.read() #Reading the captured first frame of video
        
I=first_frame   

    # Selecting the Region of Interest
r = cv2.selectROI(I, False, False)

    # Cropping the image
I_roi = I[int(r[1]):int(r[1]+r[3]), int(r[0]):int(r[0]+r[2])]

    # Display cropped image
cv2.imshow("Image", I_roi)

x=r[1]
y=r[0]
width=r[1]+r[3]
height=r[0]+r[2]

roi=I_roi
#ROI converting to HSV
hsv_roi=cv2.cvtColor(roi,cv2.COLOR_BGR2HSV)
#Calculating histogram of ROI 
roi_hist=cv2.calcHist([hsv_roi],[0],None,[180],[0,180])
# Normalising the histogram
roi_hist=cv2.normalize(roi_hist,roi_hist,0,255,cv2.NORM_MINMAX)
#Iterations=10
#Shifting step =1 unit
term_criteria=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,10,1)

while True:
    # Capturing the video
    _,frame=cap.read()  
    cv2.imshow("roi",roi)
    #Converting from RGB to HSV
    hsv=cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
    #Back projecting ROI onto the each frame
    mask=cv2.calcBackProject([hsv],[0],roi_hist,[0,180],1)
    # Mean shift tracking
    _,track_window2=cv2.meanShift(mask,(x,y,width,height),term_criteria)
    ret,track_window=cv2.CamShift(mask,(x,y,width,height),term_criteria)
    # Measured parameters of tracking windows
    x,y,w,h=track_window
    x2,y2,w2,h2=track_window2
    # Displaying ROI
    frame1=cv2.rectangle(frame,(x,y),(x+w,y+h),(255,0,0),2)
    frame_1=cv2.rectangle(frame,(x2,y2),(x2+w2,y2+h2),(0,255,0),2)
    
    cv2.imshow("Mask",mask)
    cv2.imshow("Frame",frame1)
    cv2.imshow("Frame",frame_1)
    # Box points-> vertices of box
    pts=cv2.boxPoints(ret)
    pts=np.int0(pts)
    # Correcting the kalman parameters--decreasing the error
    kalman.correct(ROI_cent(pts))
    #Prediction of input and output
    prediction=kalman.predict()
    
    frame2=cv2.rectangle(frame,(prediction[0]-(0.5*w),prediction[1]-(0.5*h)),(prediction[0]+(0.5*w),prediction[1]+(0.5*h)),(0,0,255),2)
    cv2.imshow("Frame",frame2)

    key=cv2.waitKey(1)
    if key==27:
        break
cap.release()
